# django-shopping-cart
A simple shopping cart implemented in Django.
